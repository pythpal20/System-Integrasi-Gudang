<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_gudang extends CI_Model
{
    public function listBarang()
    {
        $sql = "SELECT	*,
        (SELECT qty_mutasi FROM tb_mutasi b WHERE b.model = a.model AND b.status = '0' AND b.source = 'g75') AS soh_g75,
        (SELECT qty_mutasi FROM tb_mutasi b WHERE b.model = a.model AND b.status = '0' AND b.source = 'a50') AS soh_a50
        FROM tb_barang a";
        $query = $this->db->query($sql);
        return $query;
    }

    public function listMutasi()
    {
        $this->db->select('*');
        $this->db->from('tb_mutasi');
        $this->db->order_by('created_date', 'DESC');
        $query = $this->db->get();
        return $query;
    }

    public function getdataItem($itemCode)
    {
        $this->db->select('*');
        $this->db->from('tb_barang');
        $this->db->where('code_barang', $itemCode);
        $query = $this->db->get();

        return $query;
    }

    public function get_mutasi($skus)
    {
        $this->db->select("*");
        $this->db->from('tb_mutasi');
        $this->db->where('status', '0');
        $this->db->where('model', $skus);
        $this->db->order_by('created_date', 'DESC');

        $query = $this->db->get();
        return $query;
    }
}