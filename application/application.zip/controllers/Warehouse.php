<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Warehouse extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Data Barang';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('warehouse/dataBarang', $data);
        $this->load->view('templates/footer');
    }

    public function stockList()
    {
        $this->load->model("m_gudang");
        $list = $this->m_gudang->listBarang();

        $data = array();

        foreach ($list->result() as $ls) {
            $data[] = array(
                'id' => $ls->code_barang,
                'model' => $ls->model,
                'stok75' => $ls->stok_g75,
                'stok50' => $ls->stok_a50,
                'soh75' => $ls->stok_g75 + ($ls->soh_g75),
                'soh50' => $ls->stok_a50 + ($ls->soh_a50)
            );
        }

        print_r(json_encode($data));
    }

    public function iMutation()
    {
        $this->load->model("m_gudang");
        $mt = $this->m_gudang->listMutasi();

        $data = array();

        foreach ($mt->result() as $row) {
            $data[] = array(
                'id'        => $row->id_mutasi,
                'mutasiby'  => $row->mutasi_by,
                'model'     => $row->model,
                'jenis'     => $row->jenis_mutasi,
                'qty'       => $row->qty_mutasi,
                'source'    => $row->source,
                'status'    => $row->status,
                'tujuan'    => $row->destination
            );
        }
        print_r(json_encode($data));
    }

    public function mutasi()
    {
        $data['title'] = 'Mutasi Barang';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('warehouse/mutasiBarang', $data);
        $this->load->view('templates/footer');
    }

    public function addItem()
    {
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'trim');
        $this->form_validation->set_rules('sg75', 'Stok G-75', 'numeric|required', [
            'required' => 'Setidaknya 0'
        ]);
        $this->form_validation->set_rules('sa50', 'Stok A-50', 'numeric|required', [
            'required' => 'Setidaknya 0'
        ]);
        $this->form_validation->set_rules('model', 'SKU barang', 'trim|required|is_unique[tb_barang.model]', [
            'is_unique' => 'SKU ini sudah ada!'
        ]);
        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Data Barang';
            $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('warehouse/addBarang', $data);
            $this->load->view('templates/footer');
        } else {
            $data = [
                'code_barang'   => $this->input->post('code'),
                'model'         => $this->input->post('model'),
                'stok_g75'      => $this->input->post('sg75'),
                'stok_a50'      => $this->input->post('sa50'),
                'keterangan' => $this->input->post('keterangan'),
                'created_by' => $this->input->post('createdby'),
                'created_at' => time()
            ];
            $this->db->insert('tb_barang', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Item/ barang baru ditambahkan!</div>');
            redirect('warehouse/addItem');
        }
    }
    public function detailBarang()
    {
        $itemCode = $this->input->post('id');

        $this->load->model("m_gudang");
        $item = $this->m_gudang->getdataItem($itemCode);

        $output = '';

        foreach ($item->result() as $itm) {
            $skus = $itm->model;
            $this->load->model("m_gudang");
            $mts = $this->m_gudang->get_mutasi($skus);

            $output .= '<div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered table-striped" width="100%">
                                <tr>
                                    <th>Model</th>
                                    <td>:</td>
                                    <th>' . $itm->model . '</th>
                                    <td rowspan="5" class="table-warning" width="30%"><img src="https://horekadepot.com/image/catalog/img/'. str_replace("-", "",$itm->model) .'.jpeg" width="200px"></td>
                                </tr>
                                <tr>
                                    <th>Ketarangan</th>
                                    <td>:</td>
                                    <th>' . $itm->keterangan . '</th>
                                </tr>
                                <tr>
                                    <th>Stok G-75</th>
                                    <td>:</td>
                                    <th>' . $itm->stok_g75 . '</th>
                                </tr>
                                <tr>
                                    <th>Stok A-50</th>
                                    <td>:</td>
                                    <th>' . $itm->stok_a50 . '</th>
                                </tr>
                                <tr>
                                    <th>Created Date</th>
                                    <td>:</td>
                                    <th>' . date("d/m/Y", $itm->created_at) . '</th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <br/>
                <hr class="sidebar-divider mt-3">
                <div class="col-md-12">
                    <div class="card">
                        <h5 class="card-header card-title">Mutasi Aktif</h5>
                    
                        <div class="card-body">
                            <table class="table table-bordered table-striped tableM" width="100%" data-advanced-search="false">
                                <thead>
                                    <tr>
                                        <th>Jenis Mutasi</th>
                                        <th>Qty</th>
                                        <th>Perpindahan </th>
                                        <th>Tanggal Buat</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>';
                                foreach($mts->result() AS $mt){
                                    if($mt->jenis_mutasi == 'plus'){
                                        $a = "Penambahan Stok";
                                    } elseif($mt->jenis_mutasi == 'minus') {
                                        $a = "Pengurangan Stok";
                                    } else {
                                        $a = "Perpindahan Stok";
                                    }
                                    $output .='<tr>
                                        <td>'. $a .'</td>
                                        <td>' . $mt->qty_mutasi . '</td>
                                        <td>' . $mt->source . ' <span class="fas fa-fw fa-arrow-right"></span> ' . $mt->destination . '</td>
                                        <td>' . date("d/m/Y",$mt->created_date) . '</td>
                                        <td><span class="fas fa-fw fa-arrow-right"></span>' .$mt->keterangan . '</td>
                                    </tr>';
                                }
                                $output .='</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>';
        }

        echo $output;
    }

    public function mutasiBaru()
    {
        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Mutasi Barang';
            $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
            $data['gdg'] = $this->db->get('tb_gudang')->result_array();

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('warehouse/addMutasi', $data);
            $this->load->view('templates/footer');
        }
    }
}
