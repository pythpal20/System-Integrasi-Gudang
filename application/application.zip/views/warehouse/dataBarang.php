<!-- tambahan css -->
<style>
    #toolbar {
        margin: 0;
    }
</style>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-gray-800"><?= $title; ?></h4>
    <div class="row">
        <div class="col-lg-12">
            <div class="card border-left-primary">
                <div class="card-header">
                    <h5 class="card-title">Table Data Barang dan Stok</h5>
                </div>
                <div class="card-body">
                    <!-- bootstrap-table -->
                    <div id="toolbar">
                        <button class="btn btn-secondary tambah" data-toggle="tooltip" title="Tambah Produk baru">+ New Item</button>
                    </div>
                    <table id="tb_barang" class="tb_barang table table-bordered" data-show-toggle="true" data-show-refresh="true" data-show-pagination-switch="true" data-show-columns="true" data-mobile-responsive="true" data-check-on-init="true" data-advanced-search="true" data-id-table="advancedTable">

                    </table>
                </div>
                <div class="card-footer">
                    <small><em>Data Stok barang berdasarkan data fisik - mutasi yang belum selesai</em></small>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Detail Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body ">
                <div id="viewDetail"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<!-- javascript -->
<script>
    $(document).ready(() => {
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
            $('[rel="tooltip"]').tooltip()
        })

        $(".tambah").click(() => {
            document.location.href = "<?= base_url('warehouse/addItem') ?>";
        });
    });
    $(document).ready(() => {
        var lev = "<?= $user['role_id']; ?>";
        // console.log(lev);
        // bootstrap-table
        $table = $("#tb_barang")
        $table.bootstrapTable({
            url: "<?= base_url('warehouse/stockList'); ?>",
            toolbar: '#toolbar',
            pagination: true,
            search: true,
            columns: [{
                field: 'model',
                title: 'SKU',
                sortable: 'true'
            }, {
                field: 'soh75',
                title: 'SOH G-75',
                sortable: true,
                align: 'right'
            }, {
                field: 'soh50',
                title: 'SOH A-50',
                sortable: 'true',
                align: 'right'
            }, {
                field: 'id',
                title: 'Act.',
                align: 'center',
                formatter: function(value) {
                    if (lev == '3') {
                        return [
                            '<button class="btn btn-info lihat btn-sm" data-code="' + value + '" rel="tooltip" title="Lihat detail"><span class="fas fa-fw fa-eye"></span></button> ' +
                            '<button class="btn btn-success stok btn-sm" data-code="' + value + '" rel="tooltip" title="update stok"><span class="fas fa-fw fa-right-left"></span></button> ' +
                            '<button class="btn btn-sm btn-danger history" data-code="' + value + '"><span class="fas fa-fw fa-clock"></span></button>'
                        ]
                    } else {
                        return [
                            '<button class="btn btn-info lihat btn-sm" data-code="' + value + '" rel="tooltip" title="Lihat detail"><span class="fas fa-fw fa-eye"></span></button> ' +
                            '<button class="btn btn-success stok btn-sm" data-code="' + value + '" rel="tooltip" title="update stok" disabled><span class="fas fa-fw fa-right-left"></span></button> ' +
                            '<button class="btn btn-sm btn-danger history" data-code="' + value + '"><span class="fas fa-fw fa-clock"></span></button>'
                        ]
                    }
                }
            }]
        });
        $('body').on('click', '#tb_barang .lihat', function() {
            var id = $(this).data('code');
            $.ajax({
                method: 'POST',
                url: "<?= base_url('warehouse/detailBarang') ?>",
                data: {
                    id: id
                },
                success: function(data) {
                    $("#detailModal").modal({
                        backdrop: 'static',
                        keyboard: true,
                        show: true
                    });
                    $('#viewDetail').html(data);
                    $(".tableM").bootstrapTable({
                        search: true,
                        pagination: true
                    });
                }
            });
        });
    });
</script>