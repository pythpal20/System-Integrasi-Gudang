<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-gray-800"><?= $title; ?></h4>
    <form action="<?= base_url('warehouse/mutasiBaru'); ?>" method="POST">
        <input type="hidden" name="code" id="code" readonly>
        <div class="row">
            <div class="col-md-4">
                <div class="card border-left-primary">
                    <h6 class="card-title card-header">Mutasi Baru</h6>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">User</label>
                            <input type="text" name="uname" id="uname" value="<?= $user['user_nama']; ?>" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Jenis Mutasi</label>
                            <select name="jmutasi" id="jmutasi" class="form-control jmutasi">
                                <option value=""></option>
                                <option value="plus">Penambahan Stok</option>
                                <option value="minus">Pengurangan Stok</option>
                                <option value="mutation">Perpindahan Stok</option>
                            </select>
                        </div>
                        <div class="form-group" id="gdg_asal">
                            <label for="">Gudang asal</label>
                            <select name="gasal" id="gasal" class="form-control gasal">
                                <option value=""></option>
                                <?php foreach ($gdg as $g) : ?>
                                    <option value="<?= $g['kode_gudang']; ?>"><?= $g['locator'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group" id="gdg_tujuan">
                            <label for="">Gudang Tujuan</label>
                            <select name="gtujuan" id="gtujuan" class="form-control gtujuan">
                                <option value=""></option>
                                <?php foreach ($gdg as $g) : ?>
                                    <option value="<?= $g['kode_gudang']; ?>"><?= $g['locator'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
<!-- javaSript -->
<script>
    $(document).ready(function() {
        function makeid(length) {
            var result = [];
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
                result.push(characters.charAt(Math.floor(Math.random() *
                    charactersLength)));
            }
            return result.join('');
        }

        var codex = makeid(10);
        document.getElementById("code").value = codex;


        $(".batal").click(() => {
            window.history.back();
        });

        $(".jmutasi").select2({
            allowClear: true,
            placeholder: 'Pilih Jenis Mutasi'
        });
        $(".gasal").select2({
            allowClear: true,
            placeholder: 'Pilih gudang asal'
        });
        $(".gtujuan").select2({
            allowClear: true,
            placeholder: 'Pilih gudang tujuan'
        });
    });
    $(document).ready(function() {
        $("#gdg_asal").hide();
        $("#gdg_tujuan").hide();
        $("#jmutasi").change(function() {
            var jmut = $("#jmutasi").val();
            if (jmut == 'plus') {
                $("#gdg_asal").hide();
                $("#gdg_tujuan").show();
            } else if (jmut == 'minus') {
                $("#gdg_asal").show();
                $("#gdg_tujuan").hide();
            } else if (jmut == 'mutation') {
                $("#gdg_asal").show();
                $("#gdg_tujuan").show();
            } else {
                $("#gdg_asal").hide();
                $("#gdg_tujuan").hide();
            }
        });
    });
</script>