<!-- tambahan css -->
<style>
    #toolbar {
        margin: 0;
    }
</style>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-gray-800"><?= $title; ?></h4>
    <div class="card mb-3 border-left-primary">
        <div class="card-body">
            <div id="toolbar">
                <button class="btn btn-secondary tambah" data-toggle="tooltip" title="Tambah mutasi baru"><span class="fas fa-fw fa-plus"></span> Mutasi</button>
            </div>
            <table id="tb_mutasi" class="table table-bordered tb_mutasi table-hover" data-show-toggle="true" data-show-refresh="true" data-show-pagination-switch="true" data-show-columns="true" data-mobile-responsive="true" data-check-on-init="true" data-advanced-search="true" data-id-table="advancedTable"></table>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
<script>
    $(document).ready(() => {
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
            $('[rel="tooltip"]').tooltip()
        });

        $table = $("#tb_mutasi")
        $table.bootstrapTable({
            url: "<?= base_url('warehouse/iMutation'); ?>",
            toolbar: '#toolbar',
            pagination: true,
            search: true,
            columns: [{
                field: 'model',
                title: 'SKU',
                sortable: 'true'
            }, {
                field: 'jenis',
                title: 'Jenis Mutasi',
                sortable: 'true',
                formatter: mutation
            }, {
                field: 'qty',
                title: 'Qty. Mutasi',
                sortable: 'true'
            }, {
                field: 'mutasiby',
                title: 'Dibuat Oleh'
            }, {
                field: 'status',
                title: 'Status',
                sorable: 'true',
                formatter: status
            }, {
                field: 'id',
                title: 'Act.',
                formatter: tombol,
                align: 'center'
            }]
        });

        function status(row, value, index) {
            if (row == '0') {
                return [
                    '<span class="badge badge-info">Pending</span>'
                ]
            } else if (row === '1') {
                return [
                    '<span class="badge badge-success">Approved</span>'
                ]
            } else {
                return [
                    '<span class="badeg badge-danger">Cancel</span>'
                ]
            }
        }

        function mutation(value, row) {
            if (value == 'minus') {
                return [
                    'Pengurangan Stok'
                ]
            } else if (value == 'plus') {
                return [
                    'Penambahan Stok'
                ]
            } else if (value == 'mutasi') {
                return [
                    'Perpindahan barang'
                ]
            }
        }

        function tombol(value, row, index) {
            const dest = row.tujuan;
            if (dest == null) {

            } else if (dest == 'g75') {

            } else if (dest == 'a50') {

            }
        }

        $(".tambah").click(() =>{
            window.location.href="<?= base_url('warehouse/mutasiBaru'); ?>";
        });
    });
</script>